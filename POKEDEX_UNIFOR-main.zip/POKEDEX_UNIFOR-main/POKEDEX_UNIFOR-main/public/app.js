const estado = {
    pokemons: [],
    pokemonsFiltrados: [],
    paginaAtual: 1,
    tamanhoPagina: 20,
    termoBusca: "",
    tipoSelecionado: ""
};

const API_POKEMON = "https://pokeapi.co/api/v2/pokemon";
const API_TIPO = "https://pokeapi.co/api/v2/type";

window.onload = () => {
    mostrarEsqueletos();
    carregarOpcoesTipo();
    carregarPokemons();
};

function mostrarEsqueletos() {
    const caixa = document.getElementById("loading");
    caixa.innerHTML = "";

    for (let i = 0; i < 20; i++) {
        caixa.innerHTML += `
            <div class="col-md-3">
                <div class="skeleton"></div>
            </div>
        `;
    }
}

async function carregarOpcoesTipo() {
    try {
        const requisicao = await fetch(API_TIPO);
        const dados = await requisicao.json();
        const seletor = document.getElementById("typeFilter");

        dados.results.forEach(t => {
            const opcao = document.createElement("option");
            opcao.value = t.name;
            opcao.textContent = t.name[0].toUpperCase() + t.name.slice(1);
            seletor.appendChild(opcao);
        });
    } catch (erro) {
        console.error("Erro ao carregar tipos", erro);
    }
}

async function carregarPokemons() {
    alternarCarregamento(true);

    try {
        const deslocamento = (estado.paginaAtual - 1) * estado.tamanhoPagina;
        const resposta = await fetch(`${API_POKEMON}?limit=${estado.tamanhoPagina}&offset=${deslocamento}`);
        const dados = await resposta.json();

        const listaRequisicoes = dados.results.map(p => fetch(p.url));
        const respostas = await Promise.all(listaRequisicoes);

        estado.pokemons = await Promise.all(respostas.map(r => r.json()));
        estado.pokemonsFiltrados = [...estado.pokemons];

        renderizarPokemons();
    } catch (erro) {
        console.error("Erro ao carregar Pokémons", erro);
        alert("Falha ao carregar Pokémons.");
    }
}

async function carregarPokemonsPorTipo() {
    alternarCarregamento(true);

    try {
        const resposta = await fetch(`${API_TIPO}/${estado.tipoSelecionado}`);
        const dados = await resposta.json();

        const lista = dados.pokemon.slice(0, 100);
        const requisicoesDetalhes = lista.map(p => fetch(p.pokemon.url));

        const respostas = await Promise.all(requisicoesDetalhes);
        estado.pokemons = await Promise.all(respostas.map(r => r.json()));

        estado.pokemonsFiltrados = [...estado.pokemons];

        renderizarPokemons();
    } catch (erro) {
        console.error("Erro ao filtrar por tipo", erro);
        alert("Não foi possível carregar esse tipo agora.");
    }
}

function alternarCarregamento(habilitado) {
    document.getElementById("loading").style.display = habilitado ? "flex" : "none";
    document.getElementById("pokemonGrid").style.display = habilitado ? "none" : "flex";
}

function renderizarPokemons() {
    const grade = document.getElementById("pokemonGrid");
    grade.innerHTML = "";

    let lista = estado.pokemonsFiltrados;

    lista.forEach(p => {
        const cartao = document.createElement("div");
        cartao.className = "col-md-3";

        const tipos = p.types
            .map(t => `<span class="badge type-${t.type.name}">${t.type.name}</span>`)
            .join(" ");

        cartao.innerHTML = `
            <div class="c" onclick="mostrarDetalhes(${p.id})">
                <img src="${p.sprites.front_default}" class="i" alt="${p.name}">
                <h5 class="text-center">#${p.id} ${capitalizar(p.name)}</h5>
                <div class="text-center">${tipos}</div>
            </div>
        `;

        grade.appendChild(cartao);
    });

    alternarCarregamento(false);
    atualizarInfoPagina(lista.length);
    atualizarBotoes();
}

function atualizarInfoPagina(total) {
    const caixa = document.getElementById("pageInfo");

    if (estado.tipoSelecionado) {
        caixa.textContent = `Mostrando ${total} Pokémons`;
    } else {
        caixa.textContent = `Página ${estado.paginaAtual}`;
    }
}

function atualizarBotoes() {
    const anterior = document.getElementById("prevBtn");
    const proximo = document.getElementById("nextBtn");

    anterior.disabled = estado.paginaAtual === 1 || estado.tipoSelecionado !== "";
    proximo.disabled = estado.tipoSelecionado !== "";
}

async function aplicarFiltro() {
    estado.termoBusca = document.getElementById("s").value;
    estado.tipoSelecionado = document.getElementById("typeFilter").value;

    if (estado.termoBusca.trim()) {
        await buscarGlobal(estado.termoBusca);
    } else if (estado.tipoSelecionado) {
        await carregarPokemonsPorTipo();
    } else {
        estado.paginaAtual = 1;
        await carregarPokemons();
    }
}

async function buscarGlobal(termo) {
    alternarCarregamento(true);

    try {
        const termo_lower = termo.toLowerCase();
        const listaCompleta = [];
        let offset = 0;
        const limit = 100;

        while (offset < 1000) {
            const resposta = await fetch(`${API_POKEMON}?limit=${limit}&offset=${offset}`);
            const dados = await resposta.json();

            if (!dados.results || dados.results.length === 0) break;

            for (const item of dados.results) {
                const id = item.url.split('/').filter(Boolean).pop();
                const nome_lower = item.name.toLowerCase();

                if (nome_lower.includes(termo_lower) || id.includes(termo)) {
                    listaCompleta.push(fetch(item.url));
                }
            }

            offset += limit;
            if (listaCompleta.length >= 200) break;
        }

        if (listaCompleta.length === 0) {
            estado.pokemons = [];
            estado.pokemonsFiltrados = [];
            renderizarPokemons();
            return;
        }

        const respostas = await Promise.all(listaCompleta.slice(0, 200));
        estado.pokemons = await Promise.all(respostas.map(r => r.json()));
        estado.pokemonsFiltrados = [...estado.pokemons];

        renderizarPokemons();
    } catch (erro) {
        console.error("Erro ao buscar globalmente", erro);
        alert("Erro ao buscar Pokémons globalmente.");
    }
}

function resetarFiltros() {
    document.getElementById("s").value = "";
    document.getElementById("typeFilter").value = "";

    estado.termoBusca = "";
    estado.tipoSelecionado = "";
    estado.paginaAtual = 1;

    carregarPokemons();
}

function paginaAnterior() {
    if (estado.paginaAtual > 1) {
        estado.paginaAtual--;
        estado.tipoSelecionado ? renderizarPokemons() : carregarPokemons();
    }
}

function proximaPagina() {
    estado.paginaAtual++;
    estado.tipoSelecionado ? renderizarPokemons() : carregarPokemons();
}

function alternarTema() {
    document.body.classList.toggle("dark");
   
    const modoEscuroAtivo = document.body.classList.contains("dark");
    localStorage.setItem("modoEscuro", modoEscuroAtivo);
}

window.addEventListener("load", () => {
    const modoEscuroSalvo = localStorage.getItem("modoEscuro") === "true";
    if (modoEscuroSalvo) {
        document.body.classList.add("dark");
    }
});

async function mostrarDetalhes(id) {
    try {
        const resposta = await fetch(`${API_POKEMON}/${id}`);
        const pokemon = await resposta.json();

        const requisicaoEspecie = await fetch(pokemon.species.url);
        const especie = await requisicaoEspecie.json();

        const descricao = escolherDescricao(especie.flavor_text_entries);

        renderizarModal(pokemon, descricao);
    } catch (erro) {
        console.error("Erro ao abrir detalhes", erro);
    }
}

function escolherDescricao(entradas) {
    const en = entradas.find(x => x.language.name === "en");
    return en ? en.flavor_text.replace(/\f/g, " ") : "";
}

function renderizarModal(p, descricao) {
    document.getElementById("modalTitle").textContent = `#${p.id} ${capitalizar(p.name)}`;

    const tipos = p.types
        .map(t => `<span class="badge type-${t.type.name}">${t.type.name}</span>`)
        .join(" ");

    const habilidades = p.abilities.map(a => a.ability.name).join(", ");

    const estatisticas = p.stats
        .map(s => {
            const largura = (s.base_stat / 255) * 100;
            return `
                <div>
                    <small>${s.stat.name}: ${s.base_stat}</small>
                    <div class="stat-bar">
                        <div class="stat-fill" style="width:${largura}%"></div>
                    </div>
                </div>
            `;
        })
        .join("");

    document.getElementById("modalBody").innerHTML = `
        <div class="row">
            <div class="col-md-6">
                <div class="sprite-container">
                    <div>
                        <img src="${p.sprites.front_default}" alt="">
                        <p class="text-center">Normal</p>
                    </div>
                    <div>
                        <img src="${p.sprites.front_shiny}" alt="">
                        <p class="text-center">Shiny</p>
                    </div>
                </div>

                <p><strong>Tipo:</strong> ${tipos}</p>
                <p><strong>Altura:</strong> ${p.height / 10} m</p>
                <p><strong>Peso:</strong> ${p.weight / 10} kg</p>
                <p><strong>Habilidades:</strong> ${habilidades}</p>
            </div>

            <div class="col-md-6">
                <p><strong>Descrição:</strong></p>
                <p>${descricao}</p>
                <h6>Estatísticas:</h6>
                ${estatisticas}
            </div>
        </div>
    `;

    new bootstrap.Modal(document.getElementById("m")).show();
}

function capitalizar(texto) {
    return texto[0].toUpperCase() + texto.slice(1);
}
